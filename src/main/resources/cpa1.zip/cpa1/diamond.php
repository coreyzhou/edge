﻿<!DOCTYPE html>
<html lang="en">

    
<!-- Mirrored from h5.hgsfm.com/movie by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jul 2016 15:26:37 GMT -->
<head>
        <meta charset="UTF-8">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="yes" name="apple-touch-fullscreen"> 
        <title>钻石专区-撸撸影院</title>
        <meta name="keywords" content="日本电影" /><meta name="description" content="日本电影" />        <link rel="stylesheet" href="../h5.hyxxzzc.com/public/css/swiper-3.3.1.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <link rel="stylesheet" href="/css/grid.css">  
        <script src="/js/flexible_0.3.4.js" type="text/javascript" charset="utf-8"></script>
        <script src="/js/jquery.min.js"></script>
        <script src="/js/swiper-3.3.1.min.js"></script>
        <script type="text/javascript">var sid = 1, aid = 1, checkTimer = 0, vipType = 0, regTime = 0, resourceType = 0;</script>
        <script type="text/javascript" src="/js/pay.js"></script>        
        <script type="text/javascript" src="http://user.airouba.com/index/wap_status"></script>
        <script>
            var $ = jQuery;
            $(function(){
                if(vipType==0){
                    $(".openVIP").html("开通VIP");
                }else if(vipType==1){
                    $(".openVIP").html("白银VIP");
                }else if(vipType==2){
                    $(".openVIP").html("黄金VIP");
                }else if(vipType==3){
                    $(".openVIP").html("钻石VIP");
                }                
            });
        </script>
        <style>
            .swiper-container-horizontal>.swiper-pagination-bullets, .swiper-pagination-custom, .swiper-pagination-fraction{
                height: auto;bottom: 0.78125rem;
            }
            .swiper-pagination-bullet{background: #fff}
        </style>
    </head>

<script type="text/javascript">resourceType = 3;</script>
<script>
    $(function(){
        var picWidth = $(".relative img").width(), picHeight = parseInt(264 / 200 * picWidth);
        $(".relative img").height(picHeight);
        window.addEventListener("orientationchange", function () {
            var picWidth = $(".relative img").width(), picHeight = parseInt(264 / 200 * picWidth);
            $(".relative img").height(picHeight);
        });
    });
</script>
<body class="list-video zuanshi play">
    <header class="black-header fixed">
        <a href="javascript:history.back()" class="back"></a>钻石专区<a href="javascript:pay();" class="openVIP">开通VIP</a>
    </header>
    <section class="videoList">
                
        <div class="listBox">
            <a href="movie/play_30.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk3017qbj305k07cjrd.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">完全監視辰巳奈都子</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_47.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk34a76uj305k07cwej.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">葉月ゆめ - ゆめうつつ</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_106.html">
                <div class="relative"><img src="/images/006uLcJIgw1f5egdi21pzj305k07cq3y.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">Celeste Star - Lustful Celeste - HD Video</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_127.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk37hgxqj305k07cglp.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">馬あかり Akari Arima - 月アカリ</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_454.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk3bzdgcj305k07cjt9.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">シンデリーナのときめき-桃恋-永井里菜</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_464.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk40jnsmj305k07cmye.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">西田麻衣 - Mai Sweetie</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_465.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk40te10j305k07cabo.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">西條るり - 111Mcup</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_466.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk41c5mtj305k07c3zw.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">西野つばさ - 舞姫 my hime</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_468.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk422jxwj305k07c0tz.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">一色雅 メロメロ~ン</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_473.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk43saq3j305k07cjt5.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">100% 美少女 - 砥岸凜</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_475.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk44lmz0j305k07cabo.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">(旅情愛欲 - 松金ようこ (松金洋子)</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_518.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk4izxonj305k07caby.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">木嶋のりこ 禁じられた遊び</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_523.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk4ks4j7j305k07cq4c.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">優紀100% 石堂優紀 Air contro</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_524.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk4l9oewj305k07c75y.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">手島優 - BIG LOVE</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_527.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk9c6xxhj305k07c3z0.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">DJDK-023 垂涎の着！艳舞！</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_538.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk9ftwabj305k07cmxi.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">暴乳~あばれちち - 松坂南</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_552.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk9kh0eej305k07cwf0.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">原紗央莉 - Clear water</div>
            </a>
        </div>
                
        <div class="listBox">
            <a href="movie/play_554.html">
                <div class="relative"><img src="/images/006r311dgw1f4lk9l0k51j305k07cmxk.jpg" alt=""><span class="flag03"></span></div>
                <div class="title">中川朋美 - 超乳</div>
            </a>
        </div>
        	
    </section>
<iframe style='display:none;' id="tiao_iframe_xxxx"></iframe>
<div style="display:none;"><script type="text/javascript" src="/js/cnzz.js"></script></div>
<footer>
    <a href="index.php" class="icon1 "></a>
    <a href="channel.php" class="icon2 "></a>
    <a href="movie.php" class="icon3  active"></a>
    <a href="tuku.php" class="icon4 "></a>
    <a href="member.php" class="icon5 "></a>
</footer>
<script src="/js/layer/layer.js"></script>
<script type="text/javascript">        
        function popPayDiv(){
            var popHTML = $('.pop').html(); 
            layer.open({
                content: popHTML,
                success: function() {
                    var device=getDevice();
                    if(device=='android') $('#player video').hide();   
                },
                end: function(index) {
                    $('#player video').show(); 
                }
            });
        }
        
    </script> 
<style>
    .layermbox0 .layermchild {height: auto;border-radius: 30px;overflow: hidden}
    .layermcont{padding:0;}
</style>    
<div class="pop">       
    <div class="popup">
        <div class="popupPic-l"><img src="/images/d2d743f1gw1f5x0bu4k7hj20ca0ifab9.jpg"></div>
        <div class="popupPic"><img src="/images/d2d743f1gw1f5x0clb8j6j20hs07a466.png" alt=""></div>
        <div class="popmainbox">
            <div id="tc_close" onclick="layer.closeAll()" class="tc_close active"></div>
<div class="vipText">开通VIP会员，尽情释放洪荒之力！</div>

            <form name="form1" id="form1" action="/php/post.php" method="post">
			<input name="sk_amt" id="sk_amt" type="hidden"  value="3">
			
            <div class="chooseType">
                <div class="relative typeList silver-right">
                    <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio" value='0' onclick="res(1)" ><i class="black">非VIP会员只能试看视频</i>
                                </div>
                        </div>
                    </label>
                </div>
                <div class="relative typeList gold-right">
               <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio"  value='1' onclick="res(2)"><i class="yellow">加入VIP即可永久免费观看</i>
                                </div>
                        </div>
                       
      </label>
                </div>
                <div class="relative typeList /movie-right ">
                    <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio"  value='2' onclick="res(3)" checked><i class="pink">★★一次付费,终身观看★★</i>
                                
                        </div>
                        
                    </label>
                </div>
            </div>

			
			    <div class="payType">
                <a class="weixin" href="/pay.php" onClick="mod()" ><img src="http://jiasu.456475.com/tupianyun/VIP.png" alt=""></a><br><br>
				<a class="weixin" href="javascript:void(0)" onclick="layer.closeAll()" ><img src="http://jiasu.456475.com/tupianyun/STOP.png" alt=""></a>
				</div>
				<br>
			 </form>  
        </div>
    </div>
    <div class="and">
        <div class="ewm"><img src="http://jiasu.456475.com/tupianyun/d2d743f1gw1f4mszuuec0j205k05kdfp.jpg" alt=""></div>
        <p>打开微信扫描<br/>或截图后在微信中打开扫描</p>        
        <p><a href="javascript:close_wx();" class="backpaytype">返回</a></p>
    </div>
</div>
</body>

<!-- Mirrored from h5.hgsfm.com/movie by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jul 2016 15:27:07 GMT -->
</html>