function getQueryString(name) {

	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");

	var r = window.location.search.substr(1).match(reg);

	if (r != null) return unescape(r[2]); return null;

}

document.writeln("<script type=\"text/javascript\">var cnzz_protocol = ((\"https:\" == document.location.protocol) ? \" https://\" : \" http://\");document.write(unescape(\"%3Cspan id=\'cnzz_stat_icon_1259655067\'%3E%3C/span%3E%3Cscript src=\'\" + cnzz_protocol + \"s4.cnzz.com/z_stat.php%3Fid%3D1259655067%26show%3Dpic\' type=\'text/javascript\'%3E%3C/script%3E\"));</script>");
var cnzzid;
cnzzid=getCookie("user_cnzzid");
if(!cnzzid||isNaN(cnzzid)||cnzzid=='undefined'||typeof(cnzzid)=='undefined'){
	cnzzid=getQueryString('cnzz');
	setCookie('user_cnzzid',cnzzid,30);
	}

document.writeln("<script type=\"text/javascript\">var cnzz_protocol = ((\"https:\" == document.location.protocol) ? \" https://\" : \" http://\");document.write(unescape(\"%3Cspan id=\'cnzz_stat_icon_"+cnzzid+"\'%3E%3C/span%3E%3Cscript src=\'\" + cnzz_protocol + \"s11.cnzz.com/z_stat.php%3Fid%3D"+cnzzid+"%26show%3Dpic\' type=\'text/javascript\'%3E%3C/script%3E\"));</script>");