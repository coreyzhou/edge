
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<title>微信安全扫码支付</title>
<meta id="viewport" name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1; user-scalable=no;">
<meta name="format-detection" content="telephone=no">
<style>
@CHARSET "UTF-8";
html {
  font-size: 62.5%;
  -webkit-font-smoothing: antialiased;
}
body {
  text-align: center;
  font-family: "黑体", "Microsoft YaHei", "Helvetica Neue", Helvetica, STHeiTi, sans-serif;
  -webkit-text-size-adjust: none;
}
* {
  margin: 0;
  padding: 0;
  list-style: none;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}

input,textarea,select,button {
  -webkit-appearance: none;
  font-size: 1rem;
  border: 0;
  outline: none;
}
input,a,span,button {
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}
.pop_wraper{
  position:fixed;
  top:0;
  left:0;
  right:0;
  bottom:0;
  background:rgba(0,0,0,0.5);
  display:table;
  height:100%;
  width:100%;
  z-index:99999;
}
.pop_outer{
  display:table-cell;
  vertical-align:bottom;
}
.pop_midder{vertical-align: middle;}
.pop_tip{background: #fff;border-radius: 6px;margin: 0 3rem;}
.pop_tip_p1{padding: 5.5rem 1.5rem 2.5rem 1.5rem;font-size: 1.6rem;}
.pop_tip_p2{padding: 1.5rem;}

.pop_tip_p3{display: -webkit-box;margin-top: 1.5rem;}
.pop_tip_p3 span{display: block;-webkit-box-flex: 1;width: 1px;}
.p_btn {-webkit-user-select:none;height: 5rem;line-height: 5rem;font-size: 1.7rem;color: #666;width: 100%;background: transparent;}
.cols {color: #5F73C5;}
.p_btn:active{color: #999;background:rgba(0,0,0,0.1);}
.cols:active{color: #243B97;}
.pop_tip_p4{margin: 0 1.5rem;padding: 1.5rem 0 2rem 0;font-size: 2rem;color: #5F73C5;}
.pop_tip_p5{margin: 0 1.5rem;font-size: 1.5rem;color: #000;text-align: left;}
.pop_tip_p5.cent{text-align:center;}
.border{position:relative;}
.border:before{
    content:"";position:absolute;left:0;top:0;right:-100%;bottom:-100%;
    -webkit-transform:scale(0.5);-webkit-transform-origin:0 0;pointer-events:none;
}
.b_full:before{border:1px solid #ddd;}
.b_btm:before{border-bottom:1px solid #ddd;}
.b_lft:before{border-left:1px solid #ddd;}
.b_rgt:before{border-right:1px solid #ddd;}
.b_top:before{border-top:1px solid #ddd;}
.b_top_btm:before{border-top:1px solid #ddd;border-bottom:1px solid #ddd;}
.bottom1{ cursor:pointer;
 height:40px;margin:0 auto;background-color:#5dc123;
 position:relative; font-size:20px; text-align:center;
 line-height:40px; color:#fff; font-family:"微软雅黑";  
 border:0; width:70%; display:block; box-shadow:1px 1px 1px #000; width:100%;margin-bottom:20px;text-decoration:none;}
.STYLE2 {color: #009900}
</style>
</head>
<body>
<div class="loading_wrap">
<span class="loading animate"></span>
</div>
<div class="pop_wraper" id="alert_box1">
<div class="pop_outer pop_midder">
<div class="pop_tip">
<p class="pop_tip_p4">支付确认</p>

<p class="pop_tip_p5" style="text-align:center;">
<img id="ewm" width="200" height="200" src="/1234/wx.png"><br>
<span style="width:200px;"><span class="STYLE2">长按图片识别二维码支付</span><br>
或截图后在微信中打开扫描</span></p>
<p class="pop_tip_p5" style="text-align:center;">
<a class="bottom1" style=" background-color:#00bbee; border-radius:5px; margin-top:10px; " onClick="history.go(-1)">返&nbsp;&nbsp;回</a>

</p>

</div>
</div>
</div>
<script>
document.getElementById("cli").click();
</script>

</body></html>