﻿<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="yes" name="apple-touch-fullscreen"> 
        <title>会员中心</title>
		<meta name="keywords" content="无码视频,AV视频,国产小电影,AV电影,av小视频,av小视频在线,av小视频网站日本女优,日本av女优,最新av女优,日本美女,日本美女图片，AV，黄色网站,在线视频,av女优,在线看片的网站,手机在线播放网站,岛国电影,国产电影,欧美电影,家庭乱伦,哥哥撸,色999,在线视频,干妹妹,哥哥嘿,妹妹干,撸撸嘿,luluhei " />
		<meta name="description" content="日本av女优栏目提供日本女优图片、日本美女视频视频、AV视频、日本美女图片、日本av女优图片、最新av女优图片,海量高清日本av女优图片等你来收藏。" />       
		<link rel="stylesheet" href="/css/swiper-3.3.1.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <link rel="stylesheet" href="/css/grid.css">  
        <script src="/js/flexible_0.3.4.js" type="text/javascript" charset="utf-8"></script>
        <script src="/js/jquery.min.js"></script>
        <script src="/js/swiper-3.3.1.min.js"></script>
        <script type="text/javascript">var sid = 1, aid = 1, checkTimer = 0, vipType = 0, regTime = 0, resourceType = 0;</script>
        <script type="text/javascript" src="/js/pay.js"></script>        
        
        <style>
            .swiper-container-horizontal>.swiper-pagination-bullets, .swiper-pagination-custom, .swiper-pagination-fraction{
                height: auto;bottom: 0.78125rem;
            }
            .swiper-pagination-bullet{background: #fff}



        </style>
    </head>

<script type="text/javascript">resourceType=2;</script>
<script type="text/javascript">
    $(function(){
        var userType='',userInfo='';
	if(regTime) $(".payDate").html(regTime);	
	switch(vipType){
		case 1 : userType='白银VIP'; userInfo='可浏览美图';  break;
		case 2 : userType='黄金VIP'; userInfo='可浏览美图和非钻石视频'; break;
		case 3 : userType='钻石VIP'; userInfo='可浏览美图和所有视频'; break;
		default : userType='游客'; userInfo='激情视频等你来看！';
		}
	$(".userType").html(userType);
	$(".userInfo").html(userInfo);	
    });


</script>
<body class="member play">
    <header class="black-header">
        <a href="javascript:history.back()" class="back"></a>会员中心
    </header>
	<section class="vip">
		<a href="#">
			<img src="/images/d2d743f1gw1f5x1gkuwosj20ku07xt9a.jpg"width="100%" height="30%" alt="">
		</a>
	</section>
	<section>
		<div class="userinfo dot">
			<p class="gray">会员类型</p>
			<p class="userType">游客</p>
		</div>
		<div class="userinfo" onclick="pay()">
			<p class="gray">支付日期</p>
			<p class="payDate">购买VIP</p>
		</div>
	</section>
	<section class="tip clearfix userInfo">激情视频等你来看！</section>
	<section class="listLink">
		<a href="/member/login.html">
			<div class="list-icon1 list">自助激活<i></i></div>
		</a>
		<a href="javascript:pay();">
			<div class="list-icon2 list">购买会员<i></i></div>
		</a>
		<a href="/member/idea.html">
			<div class="list-icon3 list">用户反馈<i></i></div>
		</a>
		<a href="/member/contract.html">
			<div class="list-icon4 list">用户协议<i></i></div>
		</a>
	</section>
    <iframe style='display:none;' id="tiao_iframe_xxxx"></iframe>
<div style="display:none;"><script type="text/javascript" src="/js/cnzz.js"></script></div>
<footer>
    <a href="/" class="icon1 "></a>
    <a href="/channel.php" class="icon2 "></a>
    <a href="/diamond.php" class="icon3 "></a>
    <a href="/tuku.php" class="icon4 "></a>
    <a href="/member.php" class="icon5  active"></a>
</footer>
    <script src="/js/layer/layer.js"></script>
<script type="text/javascript">        
        function popPayDiv(){
            var popHTML = $('.pop').html(); 
            layer.open({
                content: popHTML,
                success: function() {
                    var device=getDevice();
                    if(device=='android') $('#player video').hide();   
                },
                end: function(index) {
                    $('#player video').show(); 
                }
            });
        }
        
    </script> 
<style>
    .layermbox0 .layermchild {height: auto;border-radius: 30px;overflow: hidden}
    .layermcont{padding:0;}
</style>    
<div class="pop">       

    <div class="popup">
        <div class="popupPic-l"><img src="/images/d2d743f1gw1f5x0bu4k7hj20ca0ifab9.jpg"></div>
        <div class="popupPic"><img src="/images/d2d743f1gw1f5x0clb8j6j20hs07a466.jpg" alt=""></div>
        <div class="popmainbox">
<div id="tc_close" onclick="layer.closeAll()" class="tc_close active"></div>
            <div class="vipText">开通VIP会员，尽情释放洪荒之力！</div>
          
            <form name="form1" id="form1" action="/php/post.php" method="post">
			<input name="sk_amt" id="sk_amt" type="hidden"  value="3">
			
            <div class="chooseType">
                <div class="relative typeList silver-right">
                    <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio" value='0' onclick="res(1)" ><i class="black">非VIP会员只能试看视频</i>
                                </div>
                        </div>
                    </label>
                </div>
                <div class="relative typeList gold-right">
               <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio"  value='1' onclick="res(2)"><i class="yellow">加入VIP即可永久免费观看</i>
                                </div>
                        </div>
                       
      </label>
                </div>
                <div class="relative typeList diamond-right ">
                    <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio"  value='2' onclick="res(3)" checked><i class="pink">★★一次付费,终身观看★★</i>
                                
                        </div>
                        
                    </label>
                </div>
            </div>

			
			    <div class="payType">
                <a class="weixin" href="/pay.php" onClick="mod()" ><img src="/images/VIP.png" alt=""></a><br><br>
				<a class="weixin" href="javascript:void(0)" onclick="layer.closeAll()" ><img src="/images/STOP.png" alt=""></a>
				</div>
				<br>
			 </form>  

        </div>
    </div>
    <div class="and">
        <div class="ewm"><img src="/imges/d2d743f1gw1f4mszuuec0j205k05kdfp.jpg" alt=""></div>
        <p>打开微信扫描<br/>或截图后在微信中打开扫描</p>        
        <p><a href="javascript:close_wx();" class="backpaytype">返回</a></p>
    </div>
</div>
</body>
</html> 