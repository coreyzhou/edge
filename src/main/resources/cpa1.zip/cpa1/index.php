﻿<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
			<link rel="stylesheet" href="/csspc/movie.css">
         <link rel="stylesheet" href="/csspc/index.css">
        <script src="/jspc/jquery-1.11.1.min.js"></script>
        <script type="text/javascript">var sid=1,aid=1,checkTimer,vipType=0;</script> 
        <script src="/jspc/index.js"></script>
        <script src="/jspc/global.js"></script>
        <title>AV网站-黄色网站，岛国,国产,电影,家庭乱伦，电影,女优,黄色网站,在线视频,手机在线看片网站,哥哥嘿,妹妹干,撸撸嘿</title>
<meta name="keywords" content="av网站，无码视频,无码美图,AV视频AV电影女优,日本美女图片，黄色网站,在线视频,手机在线看片网站,岛国电影,国产电影,欧美电影,家庭乱伦,干妹妹,哥哥嘿,撸撸嘿,伦理电影，激情小说，乱伦小说 " />
<meta name="description" content="av网站，在线播放小电影的网站，让您激情四射！绝无打码，AV网站，干妹妹_妹妹撸网_妹妹撸_哥哥去在线影院_哥哥浪_色哥哥_狼哥哥,独乐乐不如众乐乐,为您的生活增添激情!" />
			  <style type="text/css">
<!--
.STYLE1 {color: #FF0000}
.STYLE2 {color: #CC0099}
.STYLE3 {color: #CC0033}
.STYLE4 {
	color: #999900;
	font-weight: bold;
}
.STYLE6 {color: #0000CC}
-->
        </style>
<script type="text/javascript">
var mobileAgent = new Array("iphone", "ipod", "ipad", "android", "mobile", "blackberry", "webos", "incognito", "webmate", "bada", "nokia", "lg", "ucweb", "skyfire");
var browser = navigator.userAgent.toLowerCase(); 
var isMobile = false; 
for (var i=0; i<mobileAgent.length; i++){ if (browser.indexOf(mobileAgent[i])!=-1){ isMobile = true; 
location.href = '/wap.php';
break; } }
</script>
    </head>
        <body onLoad="htmlUpdate();">
		
    	<div class="header">
    		<div class="h-top">
    			<div class="h-top-in areaheart">                
    				<div class="h-welcom">
    					<p class="STYLE3"><a href="#" class="STYLE4"><span class="STYLE6">欢迎光 av网站，祝你看得开心！</span></a></p>
    				</div>
                    <script type="text/javascript" src="http://user.airouba.com/index/user_topbar"></script> 
    			</div>
    		</div>
<!------------------ 导航和logo ------------------>
    		<div class="h-nav">
                <div class="areaheart">
                    <a href="index.php" class="logo"></a>
                    <div class="nav">
                        <ul class="list">
                            <li><a href="index.php">首页</a></li>
                            <li><a href='moviepc/list_14.html'>亚州经典</a></li><li><a href='moviepc/list_15.html'>清纯少女</a></li><li><a href='moviepc/list_16.html'>唯美短片</a></li><li><a href='moviepc/list_17.html'>情趣诱惑</a></li><li><a href='moviepc/list_18.html'>制服丝袜</a></li>                            <li><a href="tukupc.html" target="_blank">性感美图</a></li>
                            <li class="diamond"><a href="/diamond.html"><img src="/imagespc/7ad67e6fgw1f5oy38z28qg202m00l3yb.gif" alt=""/></a></li>
                        </ul>
                    </div>
                </div>
    		</div>
            <input type="hidden" id="vipType" name="vipType" value="0" >
    	</div> 
		<div class="banner">
</div>
		
		
    	<div class="banner">
    		<div class="banner-bg">
            </div>
            <div class="banner-big">
                <ul class="list" id="list">
                                <li>
                    <a href="moviepc/play_1.html" target="_blank">
                        <img src="/imagespc/banner01.jpg" height="446" width="1180" alt=""/>
                    </a>
                </li>
                                <li>
                    <a href="moviepc/play_95.html" target="_blank">
                        <img src="/imagespc/006uLcJIgw1f6htp0ww6qj30ws0ce75k.jpg" height="446" width="1180" alt=""/>
                    </a>
                </li>
                                <li>
                    <a href="moviepc/play_520.html" target="_blank">
                        <img src="/imagespc/006uLcJIgw1f6httcv9lwj30ws0ce3z8.jpg" height="446" width="1180" alt=""/>
                    </a>
                </li>
                                <li>
                    <a href="moviepc/play_12.html" target="_blank">
                        <img src="/imagespc/006uLcJIgw1f6htp1kwfgj30ws0cedgt.jpg" height="446" width="1180" alt=""/>
                    </a>
                </li>
                                <li>
                    <a href="moviepc/play_541.html" target="_blank">
                        <img src="/imagespc/006uLcJIgw1f6httdmp93j30ws0ce3z3.jpg" height="446" width="1180" alt=""/>
                    </a>
                </li>
                                </ul>
            </div>
            <div class="banner-small">
                <ol class="turn" id="turn">
                                <li class='current' ><img src="/imagespc/banner01.jpg" height="88" width="232" alt=""/></li>
                                <li class='current' ><img src="/imagespc/006uLcJIgw1f6htp0ww6qj30ws0ce75k.jpg" height="88" width="232"/ alt=""></li>
                                <li class='current' ><img src="/imagespc/006uLcJIgw1f6httcv9lwj30ws0ce3z8.jpg" height="88" width="232"/ alt=""></li>
                                <li class='current' ><img src="/imagespc/006uLcJIgw1f6htp1kwfgj30ws0cedgt.jpg" height="88" width="232"/ alt=""></li>
                                <li class='last' ><img src="/imagespc/006uLcJIgw1f6httdmp93j30ws0ce3z3.jpg" height="88" width="232"/ alt=""></li>
                                    
                </ol>
            </div>
    	</div>    	<div class="main">
    		<div class="main-in areaheart">
    			<div class="main-01 area">
    <div class="main-top">
        <div class="content-right">
            <a href="moviepc/list_14.html" class="more">更多+</a>
        </div>
        <div class="content-left">
            <h2>亚洲经典</h2>
        </div>
    </div>
    <div class="main-show">
        <ul class="video">
                 <li >
                <a target="_blank" href="/moviepc/detail_1.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/01.jpg" alt="" class="litpic" alt="">
                    <p><img src="/imagespc/1.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_5.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j179ot0jj305k07c74o.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/5.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_9.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j17abkcwj305k07c0sq.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/9.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_17.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk1euzhbj305k07cq31.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/17.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_22.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk2xdr62j305k07cglq.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/22.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li class='last'>
                <a target="_blank" href="/moviepc/detail_47.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk34a76uj305k07cwej.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/47.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                     
          
        </ul>
    </div>
</div>    			<div class="main-01 area">
    <div class="main-top">
        <div class="content-right">
            <a target="_blank" href="/moviepc/list_15.html" class="more">更多+</a>
        </div>
        <div class="content-left">
            <h2>欧美激情</h2>
        </div>
    </div>
    <div class="main-show">
        <ul class="video">
                 <li >
                <a target="_blank" href="/moviepc/detail_95.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/KaydenKross.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/95.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_106.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="http://obxhdvbss.bkt.clouddn.com/123456789.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/106.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_567.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f4ydk40z5fj305k07cdfx.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/567.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_573.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f4yepo7px0j305k07c3yu.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/573.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_63.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f4ydjz4q3fj305k07cjre.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/63.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li class='last'>
                <a target="_blank" href="/moviepc/detail_72.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f4yemlnl8sj305k07cglo.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/72.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                     
          
        </ul>
    </div>
</div>    			<div class="main-01 area">
    <div class="main-top">
        <div class="content-right">
            <a target="_blank" href="/moviepc/list_16.html" class="more">更多+</a>
        </div>
        <div class="content-left">
            <h2>唯美短片</h2>
        </div>
    </div>
    <div class="main-show">
        <ul class="video">
                 <li >
                <a target="_blank" href="/moviepc/detail_520.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j17b547kj305k07cjrj.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/520.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_521.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j1jjv6ujj305k07c0sv.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/521.gif" style="border:0;" alt=""></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_123.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk36yyi4j305k07cwej.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/123.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_151.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk38pvxuj305k07cwen.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/151.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_456.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk3d564mj305k07cdgz.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/456.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li class='last'>
                <a target="_blank" href="/moviepc/detail_523.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk4ks4j7j305k07cq4c.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/523.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                     
          
        </ul>
    </div>
</div>    			<div class="main-01 area">
    <div class="main-top">
        <div class="content-right">
            <a target="_blank" href="/moviepc/list_17.html" class="more">更多+</a>
        </div>
        <div class="content-left">
            <h2>情趣诱惑</h2>
        </div>
    </div>
    <div class="main-show">
        <ul class="video">
                 <li >
                <a target="_blank" href="/moviepc/detail_480.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j17cgux2j305k07cjrh.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/480.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_484.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j23of98fj305k07c0ss.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/484.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_494.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk4axrvlj305k07cjtc.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/494.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_491.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk49l8k7j305k07cjss.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/491.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_482.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk46raunj305k07cwfv.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/482.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li class='last'>
                <a target="_blank" href="/moviepc/detail_483.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk470y40j305k07cjso.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/483.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                     
          
        </ul>
    </div>
</div>    			<div class="main-01 area">
    <div class="main-top">
        <div class="content-right">
            <a target="_blank" href="/moviepc/list_18.html" class="more">更多+</a>
        </div>
        <div class="content-left">
            <h2>制服丝袜</h2>
        </div>
    </div>
    <div class="main-show">
        <ul class="video">
                 <li >
                <a target="_blank" href="/moviepc/detail_512.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j29plbfij305k07c74c.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/512.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_513.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j23optwaj305k07cwek.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/513.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_503.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk4dzzn1j305k07ctaf.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/503.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_508.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk4fnzc1j305k07cq4g.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/508.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_501.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk4d5fo6j305k07cwgd.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/501.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li class='last'>
                <a target="_blank" href="/moviepc/detail_496.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk4bhex5j305k07c75r.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/496.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                     
          
        </ul>
    </div>
</div>    			<div class="main-01 area">
    <div class="main-top">
        <div class="content-right">
            <a target="_blank" href="/moviepc/list_21.html" class="more">更多+</a>
        </div>
        <div class="content-left">
            <h2>热门自拍</h2>
        </div>
    </div>
    <div class="main-show">
        <ul class="video">
                 <li >
                <a target="_blank" href="/moviepc/detail_541.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6j178jm6aj305k07cmxd.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/541.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_545.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxshm0nlj201c01cwe9.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006uLcJIgw1f6hodvn60tj305k07cwev.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/545.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_538.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk9ftwabj305k07cmxi.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/538.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_555.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk9le8tlj305k07cq3d.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/555.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li >
                <a target="_blank" href="/moviepc/detail_557.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk9m0jsyj305k07c3z1.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/557.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                  <li class='last'>
                <a target="_blank" href="/moviepc/detail_552.html">
                    <i><img src="/imagespc/7ad67e6fgw1f5oxsibuvpj201c01b0rn.jpg" height="47" width="48" alt=""></i>
                    <img src="/imagespc/006r311dgw1f4lk9kh0eej305k07cwf0.jpg" alt="" class="litpic">
                    <p><img src="/imagespc/552.gif" alt="" style="border:0;"></p>
                    <em></em>
                </a>
            </li>
                     
          
        </ul>
    </div>
</div>    		</div>
    	</div>
<a href="/member/idea.html" id="idea_btn"></a>
<div class="footer">    
    <div class="footer-in areaheart">
        <div class="f-left">
            <ul class="list">
                <!--<li><a href="#">关于会员</a></li>
                <li><a href="#">注册协议</a></li>-->
                <li><a href="member/ideapc.html">意见反馈</a></li>
                <li class="last"><a href="#">联系方式</a></li>
                

            </ul>
        </div>
        <div class="f-right">
            Copyright (c) av网站 2016 All Rights Reserved.
			


			</div>
 
    </div>
</div>  	
<!-------------------- 右侧导航 ------------------>
<div class="right-nav">
    <ul class="r-nav">
        <li class="part01"></li>
        <li class="part02"></li>
        <li class="part03"></li>
        <li class="part04"></li>
        <li class="part05"></li>
        <li class="part06"></li>
        <li class="gotop"></li>
    </ul>
</div>
<div class="gray"></div>       
        <!-- 登录 -->
        <div class="loginbox">
            <div class="login-left tcbg">
                <img src="/imagespc/cssimg/login_bg.fw.png" height="300" width="238" alt=""/>
            </div>
            <div class="login-right tcright">
                <h3 id="login-title">av网站</h3>
                <!-- 登录表单 -->
                <form action="#" method="post" name="loginform">
                    <!-- 用户名 -->
                    <div class="username">                        
                        <input id="txt" placeholder="支付宝/微信订单号" class="txt bd" type="text" name="tradeno"><br/>
                    </div>
                    <!-- 密码 -->
                    <!--<div class="password">                       
                        <input id="dl-pwd" placeholder="密码" class="pwd bd" type="password" name="pwd"><br/>
                    </div>-->
                    <!-- 登录 -->
                    <p style="width:266px; padding:15px 0; color:red;">登录提示：支付完成之后，在支付宝或微信中获取订单号，即可登录，永久有效</p>
                    <div class="denglu">
                        <input class="ckbox" type="checkbox"  checked="checked"/>
                        记住登录状态 
                        <input class="lgin bd" type="submit" value="登录" />
                    </div>
                    <!-- 注册和找回密码 -->
                    <!--<div class="ljzc">
                        <a id="ljzc" href="#">立即注册 </a>或
                        <a id="zhmm" href="#"> 找回密码</a>
                    </div>-->
                </form>
            </div>
            <div class="close">
                <img src="/imagespc/cssimg/close.jpg" alt="">
            </div>
        </div>  
<div class="paybox">
<script type="text/javascript">                	
        $(function(){            
			$("input:radio[name='payType']").change(function(){				
				loadPayInfo();
				});
				
			if(getDevice()!="pc"){
				$("#pay-center").html("手机用户可截图后扫码");
				}
			
            });
		
		function getDevice(){
			var sUserAgent= navigator.userAgent.toLowerCase(); 
			var bIsIpad= sUserAgent.match(/ipad/i) == "ipad"; 
			var bIsIphoneOs= sUserAgent.match(/iphone/i) == "iphone";
			var bIsMidp= sUserAgent.match(/midp/i) == "midp";
			var bIsUc7= sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
			var bIsUc= sUserAgent.match(/ucweb/i) == "ucweb";
			var bIsAndroid= sUserAgent.match(/android/i) == "android";
			var bIsCE= sUserAgent.match(/windows ce/i) == "windows ce";
			var bIsWM= sUserAgent.match(/windows mobile/i) == "windows mobile";
			if(bIsAndroid){
				 return "android";
				}
			else if(bIsIpad||bIsIphoneOs){
				 return "ios";
				}
			else return "pc"	
			}
			
		function loadPayInfo(){              
			var payType=$("input:radio[name='payType']:checked").val();
			var vipType=$("#vipType").val();
			$.post("/index.php/pay/index",{vipType:vipType,payType:payType,sid:sid,aid:aid,device:"pc"},function(data){
				$("#price").text(data.info.money);
				$("#pay_ewm").attr("src",data.info.ewm);
				$("#payInfo").html(data.info.payInfo);
				},'json');                                             
			}
		
		function ali_active(){
			var tradeno=$("#ali_tradeno").val(),btn=$(".tjiao");
			btn.html("正在激活...");
			$.getScript("http://api.maoliangdong.com/newActiveOrder.php?tradeno="+tradeno+"&sid="+sid+"&aid="+aid,function(){ 
				if(activeResult==1){					
					btn.html("激活成功，页面正在跳转");
					$.getScript("http://user.airouba.com/index/renew_vip_statu/id/"+orderId+"/name/"+tradeno);	
					location.reload();
					}
				else{
					btn.html("激活失败，请稍候重试");
					}	
				})
			}	
			
    </script>
            <!-- <div class="close">
                <img src="/public/zhuifeng/images/close01.jpg" alt="">
            </div> -->
            <div class="pay-lf">
                <img src="/imagespc/d2d743f1gw1f4daa4fnuvj209v0cimyo.jpg" height="450" width="355" alt="">
            </div>
            <div class="pay-main">
                    <div class="pay-way">
                        <span>支付方式：</span>
                        <input id="weixin" value="weixin" class="p-wx" type="radio" name="payType" checked="checked"/>
                        <input id="zhifubao" value="alipay" class="p-zfb" type="radio" name="payType" />
                        <i></i>
                        <em></em>
                    </div>
                    <div class="pay-name">
                        <span>商品名称：<i>VIP会员</i>（<span id='payInfo'>开启<em>视频</em>中心权限</span>）</span>
                    </div>
                    <div class="pay-pic">
                        <span>单　　价：</span>
                        <b><i id="price"></i>元<em>（一次购买，永久有效）</em></b>
                    </div>
                    <div class="pay-explain">
                        <span>使用说明：</span>
                        <i class="exp1">扫码支付完成之后刷新页面，尽享奇妙之旅！</i>
                        <i class="exp2">支付宝扫码支付完成之后刷新页面，尽享奇妙之旅！</i>
                    </div>
                    <div class="pay-ewm1">
                        <img id="pay_ewm" src="/1234/wx.png" height="160" width="160" alt="">
                    </div>
					<div class="pay-ewm2">
                        <img id="pay_ewm" src="/1234/zfb.png" height="160" width="160" alt="">
                    </div>
                    <div id="p-weixin">
                        <img src="/imagespc/cssimg/p-weixin.jpg" height="40" width="164" alt="">
                    </div>
                    <div id="p-zhifubao">
					
						<input class="ddh" id="ali_tradeno" type="text" placeholder="请输入支付宝订单号">
                        <a style="display:inline-block;" class="tjiao" href="javascript:ali_active();">激活</a>

                        <span>（<a href="http://jingyan.baidu.com/article/64d05a024c8579de55f73b3f.html" target="_blank">如何获取?</a>）</span>
                    </div>
            </div>
            <div class="pay-rgt">
                <img id="wxpic" src="/imagespc/cssimg/ktvip_rgt01.png" height="368" width="272" alt="">
                <img id="zfpic" src="/imagespc/cssimg/zfb.gif" height="390" width="288" alt="">
            </div>
        </div>       
    </body>

<!-- Mirrored from kzaby.pw/tuku by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Jun 2016 05:23:50 GMT -->
</html>