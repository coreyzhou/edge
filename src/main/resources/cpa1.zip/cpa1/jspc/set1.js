﻿function htmlUpdate() { 
var insertText = "123456"; //修改价格
document.getElementById("price").innerHTML = insertText; 
document.getElementById("WIDtotal_fee").value = insertText;


}












