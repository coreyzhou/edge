﻿
<!DOCTYPE html>
<html lang="en">

    
<!-- Mirrored from h5.hgsfm.com/channel by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jul 2016 15:26:31 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="UTF-8">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="yes" name="apple-touch-fullscreen"> 
        <title>频道</title>
		<meta name="keywords" content="无码视频,AV视频,国产小电影,AV电影,av小视频,av小视频在线,av小视频网站日本女优,日本av女优,最新av女优,日本美女,日本美女图片，AV，黄色网站,在线视频,av女优,在线看片的网站,手机在线播放网站,岛国电影,国产电影,欧美电影,家庭乱伦,哥哥撸,色999,在线视频,干妹妹,哥哥嘿,妹妹干,撸撸嘿,luluhei " />
		<meta name="description" content="日本av女优栏目提供日本女优图片、日本美女视频视频、AV视频、日本美女图片、日本av女优图片、最新av女优图片,海量高清日本av女优图片等你来收藏。" />
        <link rel="stylesheet" href="/css/swiper-3.3.1.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <link rel="stylesheet" href="/css/grid.css">  
        <script src="/js/flexible_0.3.4.js" type="text/javascript" charset="utf-8"></script>
        <script src="js/jquery.min.js"></script>
        <script src="/js/swiper-3.3.1.min.js"></script>
        <script type="text/javascript">var sid = 1, aid = 1, checkTimer = 0, vipType = 0, regTime = 0, resourceType = 0;</script>
        <script type="text/javascript" src="/js/pay.js"></script>        
        <script type="text/javascript" src="http://user.airouba.com/index/wap_status"></script>
        <script>
            var $ = jQuery;
            $(function(){
                if(vipType==0){
                    $(".openVIP").html("开通VIP");
                }else if(vipType==1){
                    $(".openVIP").html("白银VIP");
                }else if(vipType==2){
                    $(".openVIP").html("黄金VIP");
                }else if(vipType==3){
                    $(".openVIP").html("钻石VIP");
                }                
            });
        </script>
        <style>
            .swiper-container-horizontal>.swiper-pagination-bullets, .swiper-pagination-custom, .swiper-pagination-fraction{
                height: auto;bottom: 0.78125rem;
            }
            .swiper-pagination-bullet{background: #fff}
        </style>
    </head>

<script type="text/javascript">resourceType=2;</script>
<body class="channel play">
    <header class="black-header fixed">
        <span class="logo"><img src="/images/d2d743f1gw1f5x32xdn4dj203k03kt9e.png" alt=""></span>频道<a href="javascript:pay();" class="openVIP">开通VIP</a>
    </header>
    <!--第一排-->
    <section class="channelBox col-md-12">
        <div class="mainbox">
            <div class="col-md-8 relative">
                <div class="col-md-6">
                    <div class="c1"><img src="/images/d2d743f1gw1f5x0b4in32j205k05kt8j.jpg" alt=""></div>
                </div>
                <div class="col-md-6">
                    <div class="c1top">
                        <div class="pd20"  data-id="14">
                            <p class="title">亚洲经典</p>
                            <p><span class="red total">1528</span>部精品等您品鉴</p>
                            <p>今日更新<span class="red renew">21</span>部</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="v1"><img src="/images/d2d743f1gw1f5x0b61aeoj205k05kjr7.jpg" alt=""></div>
            </div>
        </div>
    </section>
    <section class="channelBox col-md-12">
        <div class="mainbox pt0">
            <div class="col-md-8 bluelineContent">&nbsp;</div>
            <div class="col-md-4">
                <div class="blueline"></div>
            </div>
        </div>
    </section>
    <section class="channelBox col-md-12">
        <div class="mainbox2">
            <div class="col-md-4">
                <div class="pl10">
                    <div class="c2top">
                        <div class="pd20"  data-id="16">
                            <p class="title">唯美短片</p>
                            <p><span class="red total">1528</span>部精品等您品鉴</p>
                            <p>今日更新<span class="red renew">21</span>部</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="pl10">
                    <img src="/images/d2d743f1gw1f5x0b6i1mvj205k05kwee.jpg" alt="">
                </div>
            </div>
            <div class="col-md-4">
                <div class="pl10">
                    <div class="c3top">
                        <div class="pd20"  data-id="15" >
                            <p class="title">唯美短片</p>
                            <p><span class="red total">1528</span>部精品等您品鉴</p>
                            <p>今日更新<span class="red renew">21</span>部</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="channelBox col-md-12 top01">
        <div class="mainbox2">
            <div class="col-md-4">
                <div class="pl10">
                    <div class="pinkline"></div>
                </div>
            </div>
            <div class="col-md-8 bluelineContent">&nbsp;</div>
        </div>
    </section>
    <section class="channelBox col-md-12">
        <div class="mainbox2">
            <div class="col-md-4">
                <div class="pl10">
                    <img src="/images/d2d743f1gw1f5x0b71z89j205k05k743.jpg" alt="">
                </div>
            </div>
            <div class="col-md-4">
                <div class="pl10">
                    <div class="c4top">
                        <div class="pd20"  data-id="17">
                            <p class="title">情趣诱惑</p>
                            <p><span class="red total">1528</span>部精品等您品鉴</p>
                            <p>今日更新<span class="red renew">21</span>部</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="pl10">
                    <img src="/images/d2d743f1gw1f5x0b78m4mj205k05ka9w.jpg" alt="">
                </div>
            </div>
        </div>
    </section>
    <section class="channelBox col-md-12">
        <div class="mainbox">
            <div class="col-md-8 relative">
                <div class="col-md-6">
                    <div class="pl10">
                        <div class="c5top">
                            <div class="pd20"  data-id="18">
                                <p class="title">寂寞少妇</p>
                                <p><span class="red total">1528</span>部精品等你品鉴</p>
                                <p>今日更新<span class="red renew">21</span>部</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="c1"><img src="/images/d2d743f1gw1f5x0b86lvaj205k05k3yc.jpg" alt=""></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="pl10">
                    <div class="c6top">
                        <div class="pd20"  data-id="20">
                            <p class="title" >制服丝袜</p>
                            <p><span class="red total">1528</span>部精品等您品鉴</p>
                            <p>今日更新<span class="red renew">21</span>部</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="channelBox col-md-12 top01">
        <div class="mainbox pt0">
            <div class="col-md-8 purpleContent">&nbsp;</div>
            <div class="col-md-4">
                <div class="purpleline"></div>
            </div>
        </div>
    </section>
    <section class="channelBox col-md-12 top01">
        <div class="mainbox pt0">
            <div class="col-md-8 relative">
                <div class="col-md-6">
                    <div class="c1"><img src="/images/d2d743f1gw1f5x0b8zln4j205k05kdfn.jpg" alt=""></div>
                </div>
                <div class="col-md-6">
                    <div class="c7top">
                        <div class="pd20" data-id="21">
                            <p class="title" >热门自拍</p>
                            <p><span class="red total">1528</span>部精品等您品鉴</p>
                            <p>今日更新<span class="red renew">21</span>部</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="v1"><img src="/images/d2d743f1gw1f5x0b8zgr1j205k05kmx1.jpg" alt=""></div>
            </div>
        </div>
    </section>
    <section class="col-md-12 channelBoxBottom">
        <div class="mainbox pl10 relative" onclick="location.href='tuku.php'">
            <img src="/images/d2d743f1gw1f5x0b9e6xlj20h805x0so.jpg" alt="">
            <div class="channelBoxBottomFont">
                <p class="title">激情美图</p>
                <p><span class="red">12896</span>套高清套图等您品鉴</p>
                <p>今日更新<span class="red">121</span>套</p>
            </div>
        </div>
    </section>
<iframe style='display:none;' id="tiao_iframe_xxxx"></iframe>
<footer>
    <a href="index.php" class="icon1 "></a>
    <a href="channel.php" class="icon2  active"></a>
    <a href="diamond.php" class="icon3 "></a>
    <a href="tuku.php" class="icon4 "></a>
    <a href="member.php" class="icon5 "></a>
</footer>
<script src="/js/layer/layer.js"></script>
<script type="text/javascript">        
        function popPayDiv(){
            var popHTML = $('.pop').html(); 
            layer.open({
                content: popHTML,
                success: function() {
                    var device=getDevice();
                    if(device=='android') $('#player video').hide();   
                },
                end: function(index) {
                    $('#player video').show(); 
                }
            });
        }
        
    </script> 
<style>
    .layermbox0 .layermchild {height: auto;border-radius: 30px;overflow: hidden}
    .layermcont{padding:0;}
</style>    
<div class="pop">       
    <div class="popup">
        <div class="popupPic-l"><img src="/images/d2d743f1gw1f5x0bu4k7hj20ca0ifab9.jpg"></div>
        <div class="popupPic"><img src="/images/d2d743f1gw1f5x0clb8j6j20hs07a466.png" alt=""></div>
        <div class="popmainbox">
            <div id="tc_close" onclick="layer.closeAll()" class="tc_close active"></div>
<div class="vipText">开通VIP年会员，尽情释放洪荒之力！</div>

            <form name="form1" id="form1" action="/php/post.php" method="post">
			<input name="sk_amt" id="sk_amt" type="hidden"  value="3">
			
            <div class="chooseType">
                <div class="relative typeList silver-right">
                    <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio" value='0' onclick="res(1)" ><i class="black">非VIP会员只能试看视频</i>
                                </div>
                        </div>
                    </label>
                </div>
                <div class="relative typeList gold-right">
               <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio"  value='1' onclick="res(2)"><i class="yellow">加入VIP即可永久免费观看</i>
                                </div>
                        </div>
                       
      </label>
                </div>
                <div class="relative typeList diamond-right ">
                    <label>
                        <div class="type">
                            <div class="typePos">
                                <input type="radio" name="xxx" class="grayRadio"  value='2' onclick="res(3)" checked><i class="pink">★★一次付费,终身观看★★</i>
                                
                        </div>
                        
                    </label>
                </div>
            </div>

			
			    <div class="payType">
                <a class="weixin" href="/pay.php" onClick="mod()" ><img src="/images/VIP.png" alt=""></a><br><br>
				<a class="weixin" href="javascript:void(0)" onclick="layer.closeAll()" ><img src="/images/STOP.png" alt=""></a>
				</div>
				<br>
			 </form>      
        </div>
    </div>
    <div class="and">
        <div class="ewm"><img src="/images/d2d743f1gw1f4mszuuec0j205k05kdfp.jpg" alt=""></div>
        <p>打开微信扫描<br/>或截图后在微信中打开扫描</p>        
        <p><a href="/movie/alipay" class="backpaytype">返回</a></p>
    </div>
</div>
</body>
<script>
    $(function () {
        var c1_imgH = $('.c1 img').height();
        var c1_imgW = $('.c1 img').width();
        $('.c1top').css('height', $('.c1').width());
        $('.c2top').css('height', $('.c2top').width());
        $('.c3top').css('height', $('.c3top').width());
        $('.c4top').css('height', $('.c4top').width());
        $('.c5top').css('height', $('.c5top').width());
        $('.c6top').css('height', $('.c6top').width());
        $('.c7top').css('height', $('.c1').width());

        $('.blueline').css('width', c1_imgW);
        $('.purpleline').css('width', c1_imgW);
        $('.bluelineContent').css('height', $('.blueline').height());
        $('.purpleContent').css('height', $('.purpleline').height());
        $(".pd20").each(function (i, e) {
            var id = $(e).data("id");
            $(e).parent().parent().parent().parent().bind("click", function () {
                location.href="/movie/list_"+id+".html";
            });
            $.post("/index.php/index/channel_info", {id: id}, function (data) {
                $(e).find(".title").html(data.info.name);
                $(e).find(".total").html(data.info.count);
                $(e).find(".renew").html(data.info.renew);
            });
        });
    });
</script>


<!-- Mirrored from h5.hgsfm.com/channel by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jul 2016 15:26:36 GMT -->
</html> 